/**
 * Customers class
 * 
 * Purpose: XML helper class to support deserialization of customerFile.XML
 * 
 * Programmers: Kailla Bryson and Dontez Wherry
 * 
 * Course:     IS 2043 008
 * Semester:   Spring 2019
 * Assignment: PA04
 */

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;

public class Customers {
  
   // @XMLElment specifies XML element name for each object in the List
  @XmlElement(type = Customer.class, name = "customer")
  
  private List<Customer> customers = new ArrayList<>(); // stores Customers
  
  //return the List<Customer>
  public List<Customer> getCustomers() 
  {
    return customers;
    
  } // end list<Customer>
  
  
} // end class Customers
